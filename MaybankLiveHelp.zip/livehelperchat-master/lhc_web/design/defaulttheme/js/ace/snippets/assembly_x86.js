ace.define("ace/snippets/assembly_x86",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="assembly_x86"});                (function() {
                    ace.require(["ace/snippets/assembly_x86"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            